NEXA Version 1.2 — Android project

මෙම ZIP එක APK එකක් නොව Android source project එකකි.

APK එක සෑදීමට:
1. ZIP එක extract කර Android Studio තුළ project folder එක open කරන්න.
2. Gradle sync අවසන් වන තුරු රැඳී සිටින්න.
3. Build > Build Bundle(s) / APK(s) > Build APK(s) තෝරන්න.
4. Build සාර්ථක නම් app/build/outputs/apk/debug/app-debug.apk ගොනුව ලැබේ.

GitHub Actions මගින්:
1. ZIP එක extract කර files GitHub repository එකේ main branch එකට upload කරන්න.
2. Actions tab > “Build NEXA APK” > Run workflow තෝරන්න.
3. Workflow එක සාර්ථක නම් NEXA-debug-apk artifact එක download කරන්න.

සීමා:
- Android SDK නොමැති නිසා මෙම පරිසරයේ APK compile කර හෝ සැබෑ දුරකථනයක පරීක්ෂා කර නැත.
- Camera සහ microphone functionality සැබෑ Android device එකක අනිවාර්යයෙන් පරීක්ෂා කරන්න.
- Online backend/database/media storage configure කර නැත; මේ නිසා අනෙක් පරිශීලකයන් අතර posts, likes, comments, orders ආදිය sync නොවේ.
- Public release එකකට signed AAB, privacy policy, moderation/report/block සහ Play Console requirements සම්පූර්ණ කළ යුතුය.


Camera enhancement note (Version 30): added selectable preview/photo filters, basic beauty-style image adjustments, 3/10-second photo timer, 15/30/60-second auto-stop recording, and torch toggle when supported. Music can be selected and previewed, but it is NOT mixed into the recorded video. Filters currently affect the live preview and captured photos; video filter export is not guaranteed. Test on a physical Android device before release.
